<?php
/**
 * @version    1.0.2
 * @component  com_ra_members
 * @author     Charlie Bigley <webmaster@bigley.me.uk>
 * @copyright  2023 Charlie Bigley
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 * 25/04/26 CB created
 */
// No direct access
defined('_JEXEC') or die;

use \Joomla\CMS\Factory;
        $wa = Factory::getApplication()->getDocument()->getWebAssetManager();
        $wa->registerAndUseStyle('ramblers', 'com_ra_tools/ramblers.css');
echo 'SalesForce id: <b>' . $this->item->salesforceId . ', Mem No: ' . $this->item->membershipNumber . '</b><br>';
echo 'Name: <b>' . $this->item->title . ' ' . $this->item->firstName . ' ' . $this->item->lastName . '</b><br>';
echo 'Home group: <b>' . $this->item->group_code . '</b><br>';
echo 'Address: <b>' . $this->item->address1;
if ($this->item->address2 !== '') {
    echo ', ' . $this->item->address2;
}
if ($this->item->address3 !== '') {
    echo ', ' . $this->item->address3;
}
if ($this->item->town !== '') {
    echo ', ' . $this->item->town;
}
if ($this->item->county !== '') {
    echo ', ' . $this->item->county;
}
if ($this->item->country !== '') {
    echo ', ' . $this->item->country;
}
if ($this->item->postcode !== '') {
    echo ', ' . $this->item->postcode;
}
echo '</b><br>';
echo 'Phone: ';
if ($this->item->mobileNumber !== '') {
    echo 'Mobile <b>' . $this->item->mobileNumber . '</b>';
}
if ($this->item->landlineTelephone !== '') {
    echo ', Landline <b>' . $this->item->landlineTelephone . '</b>';
}
echo '</b><br>';
echo 'Member Type: <b>' . $this->item->memberType . '</b><br>';
echo 'Membership Type: <b>' . $this->item->membershipType . '</b><br>';
echo 'Member Status: <b>' . $this->item->memberStatus . '</b><br>';
echo 'Membership Term:<b> ' . $this->item->memberTerm . '</b><br>';
echo 'Joined: ';
if ($this->item->ramblersJoinDate !== '') {
    echo 'Ramblers <b>' . $this->item->ramblersJoinDate . '</b>';
}
if (!is_null($this->item->areaJoinDate)) {
    echo ', Area <b>' . $this->item->areaJoinDate . '</b>';
}
if (!is_null($this->item->groupJoinDate)) {
    echo ', Group <b>' . $this->item->groupJoinDate . '</b>';
}
echo '</b><br>';
$this->showAudit();
// $target = 'administrator/index.php?option=com_ra_members&task=member.showAudit&id=' . $this->item->id;
// echo $this->toolsHelper->buildButton($target, 'Membership audit');

$back = 'administrator/index.php?option=com_ra_members&view=members';
echo $this->toolsHelper->backButton($back);
echo '<br>';
echo var_dump($this->item);
echo '<br>';