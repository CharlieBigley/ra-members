<?php

/**
 * @version    1.0.0
 * @package    com_ra_members
 */

namespace Ramblers\Component\Ra_members\Administrator\Model;

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\MVC\Model\AdminModel;
use Joomla\CMS\Plugin\PluginHelper;
use Joomla\CMS\Table\Table;
use Joomla\CMS\Event\Model;
use Joomla\CMS\Language\Text;

class OrganisationModel extends AdminModel
{
    protected $text_prefix = 'COM_RA_MEMBERS';

    public $typeAlias = 'com_ra_members.organisation';

    protected $item = null;

    public function getTable($type = 'Organisation', $prefix = 'Administrator', $config = [])
    {
        return parent::getTable($type, $prefix, $config);
    }

    public function getForm($data = [], $loadData = true)
    {
        $form = $this->loadForm(
            'com_ra_members.organisation',
            'organisation',
            [
                'control' => 'jform',
                'load_data' => $loadData,
            ]
        );

        return empty($form) ? false : $form;
    }

    protected function loadFormData()
    {
        $data = Factory::getApplication()->getUserState('com_ra_members.edit.organisation.data', []);

        if (empty($data)) {
            if ($this->item === null) {
                $this->item = $this->getItem();
            }

            $data = $this->item;
        }

        return $data;
    }

    public function getItem($pk = null)
    {
        if ($item = parent::getItem($pk)) {
            if (isset($item->params)) {
                $item->params = json_encode($item->params);
            }

            if (!empty($item->logo) && strpos($item->logo, '/') === false) {
                $item->logo = 'images/com_ra_mailman/' . $item->logo;
            }
        }

        return $item;
    }

    public function duplicate(&$pks)
    {
        $app = Factory::getApplication();
        $user = $app->getIdentity();
        $dispatcher = $this->getDispatcher();

        if (!$user->authorise('core.create', 'com_ra_members')) {
            throw new \Exception(Text::_('JERROR_CORE_CREATE_NOT_PERMITTED'));
        }

        $context = $this->option . '.' . $this->name;
        PluginHelper::importPlugin($this->events_map['save']);
        $table = $this->getTable();

        foreach ($pks as $pk) {
            if (!$table->load($pk, true)) {
                throw new \Exception($table->getError());
            }

            $table->id = 0;

            if (!$table->check()) {
                throw new \Exception($table->getError());
            }

            if (!empty($table->nation_id) && is_array($table->nation_id)) {
                $table->nation_id = implode(',', $table->nation_id);
            } elseif (empty($table->nation_id)) {
                $table->nation_id = '';
            }

            $beforeSaveEvent = new Model\BeforeSaveEvent($this->event_before_save, [
                'context' => $context,
                'subject' => $table,
                'isNew' => true,
                'data' => $table,
            ]);

            $result = $dispatcher->dispatch($this->event_before_save, $beforeSaveEvent)->getArgument('result', []);

            if (in_array(false, $result, true) || !$table->store()) {
                throw new \Exception($table->getError());
            }

            $dispatcher->dispatch($this->event_after_save, new Model\AfterSaveEvent($this->event_after_save, [
                'context' => $context,
                'subject' => $table,
                'isNew' => true,
                'data' => $table,
            ]));
        }

        $this->cleanCache();

        return true;
    }

    protected function prepareTable($table)
    {
        if (empty($table->id) && @$table->ordering === '') {
            $db = $this->getDbo();
            $db->setQuery('SELECT MAX(ordering) FROM #__ra_organisations');
            $max = $db->loadResult();
            $table->ordering = $max + 1;
        }
    }
}