<?php

echo 'SalesForce id: <b>' . $this->item->salesforceId . ', Mem No: ' . $this->item->membershipNumber . '</b><br>';
echo 'Name: <b>' . $this->item->title . ' ' . $this->item->firstName . ' ' . $this->item->lastName . '</b><br>';
echo 'Home group: <b>' . $this->item->group_code . '</b><br>';
echo 'Address: <b>' . $this->item->address1;
if ($this->item->address2 !== '') {
    echo ', ' . $this->item->address2;
}
if ($this->item->address3 !== '') {
    echo ', ' . $this->item->address3;
}
if ($this->item->town !== '') {
    echo ', ' . $this->item->town;
}
if ($this->item->county !== '') {
    echo ', ' . $this->item->county;
}
if ($this->item->country !== '') {
    echo ', ' . $this->item->country;
}
if ($this->item->postcode !== '') {
    echo ', ' . $this->item->postcode;
}
echo '</b><br>';
echo 'Phone: ';
if ($this->item->mobileNumber !== '') {
    echo 'Mobile <b>' . $this->item->mobileNumber . '</b>';
}
if ($this->item->landlineTelephone !== '') {
    echo ', Landline <b>' . $this->item->landlineTelephone . '</b>';
}
echo '</b><br>';
echo 'Member Type: <b>' . $this->item->memberType . '</b><br>';
echo 'Membership Type: <b>' . $this->item->membershipType . '</b><br>';
echo 'Member Status: <b>' . $this->item->memberStatus . '</b><br>';
echo 'Membership Term:<b> ' . $this->item->memberTerm . '</b><br>';
echo 'Joined: ';
if ($this->item->ramblersJoinDate !== '') {
    echo 'Ramblers <b>' . $this->item->ramblersJoinDate . '</b>';
}
if (!is_null($this->item->areaJoinDate)) {
    echo ', Area <b>' . $this->item->areaJoinDate . '</b>';
}
if (!is_null($this->item->groupJoinDate)) {
    echo ', Group <b>' . $this->item->groupJoinDate . '</b>';
}
echo '</b><br>';
echo '<br>';
echo var_dump($this->item);
echo '<br>';